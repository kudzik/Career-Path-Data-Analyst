# bigquery-course

Repozytorium jest częścią kursu [Big Data: Analiza danych przy użyciu SQL oraz BigQuery (GCP)](https://www.udemy.com/course/big-data-bigquery/?referralCode=10C0A466D6710285AEC6)

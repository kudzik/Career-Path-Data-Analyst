-- 1. Wybierz 5 pierwszych wierszy z tabeli images ze zbioru open_images.

-- 2. Policz liczbę wierszy w tabeli images

-- 3. Policz unikalną liczbę wierszy w tabeli images w oparciu o kolumnę image_id

-- 4. Policz unikalną liczbę wartości kolumny title

-- 5. Wybierz kolumny: image_id, subset, original_url, title, original_size z tabeli images ze zbioru open_images.

-- 6. Wybierz 5 zdjęć z najmniejszym rozmiarem

-- 7. Wybierz 5 zdjęć z największym rozmiarem

-- 8. Wybierz unikalne wartości dla kolumny subset (rodzaj zbioru)

-- 9. Policz częstość występowania każdego rodzaju zbioru w tabeli images
  
-- 10. Policz częstość występowania (procentowo) każdego rodzaju zbioru w tabeli images
  
-- 11. Policz częstość występowania (procentowo) każdego rodzaju zbioru w tabeli images, wynik zaokrąglij do 4 miejsca po przecinku 
  
-- 12. Wybierz 5 pierwszych wierszy z tabeli labels ze zbioru open_images.
  
-- 13. Połącz metodą INNER JOIN tabele images oraz labels. Wybierz kolumny: image_id, subset, original_url, title, original_size
--    source, label_name, confidence oraz wyświetl 5 pierwszych wierszy

-- 14. Wybierz 5 pierwszych wierszy z tabeli dict ze zbioru open_images.

-- 15. Połącz metodą INNER JOIN tabele images, labels oraz dict. Wybierz kolumny: image_id, subset, original_url, title, original_size
--    source, label_name, confidence, label_display_name oraz wyświetl 5 pierwszych wierszy
